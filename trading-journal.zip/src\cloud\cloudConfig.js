// Copiá este archivo a "cloudConfig.js" (mismo directorio) y completá
// con los valores reales de tu proyecto — Supabase → Project Settings
// → API.
//
// "cloudConfig.js" debe estar en .gitignore: no porque estos valores
// sean secretos (la anon key está pensada para ser pública), sino para
// que cada quien pueda tener su propio proyecto de Supabase (ej. uno
// de prueba y otro real) sin pisarse el archivo entre sí.

export const SUPABASE_URL = "https://flyrbjqtlkbvhlxvvfhj.supabase.co";
export const SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImZseXJianF0bGtidmhseHZ2ZmhqIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODU2NjQ3MDIsImV4cCI6MjEwMTI0MDcwMn0.XuI_81OEqYYqIdJFMar6g1CSeCgc9a4gC9IGQf9I8ws";
